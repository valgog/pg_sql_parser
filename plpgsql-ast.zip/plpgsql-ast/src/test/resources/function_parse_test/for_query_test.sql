SELECT c_id
from zal_Data.commission
where c_id = 12;
